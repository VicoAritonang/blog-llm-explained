# NeuroLab — Product Design

**Working title:** NeuroLab: Ikuti Perjalanan Satu Token.  
**Tagline:** Dari teks menjadi angka, dari angka menjadi token berikutnya.  
**Status:** rancangan v1, 14 Oktober 2026. Detail teknis: [system.md](system.md).

## 1. Visi produk

NeuroLab adalah artikel interaktif dalam blog portofolio seorang Applied AI Engineer. Pengunjung memasuki laboratorium 3D, memilih contoh, lalu mengikuti perubahan representasi teks sampai model memilih token berikutnya. Mereka dapat berjalan di lab, mendekati instrumen, menghentikan waktu, memilih sel matriks, dan melihat asal angkanya.

Nilai portofolionya datang dari kemampuan menjelaskan hubungan antarkomponen secara tepat: menelusuri skor attention, membedakan bobot model dengan aktivasi, atau menjelaskan pekerjaan yang dihemat KV cache. Kedalaman teknis dapat diperiksa langsung, tidak bergantung pada klaim bahwa pembuatnya memahami AI.

Lab adalah metafora ruang belajar, bukan bentuk fisik model. Mesin, rel, dan cahaya membantu orientasi. Penanda ringan selalu tersedia: **“Simulator edukasi. Angka diperkecil dan dikurasi; bukan keluaran GPT-2 asli.”** Detail provenance ada di inspector.

## 2. Audiens dan kedalaman

Audiens utama: software/data engineer, analis, dan profesional IT yang mengenal array, tabel, fungsi, serta matematika dasar, tetapi belum menguasai tensor/LLM. Kalkulus bukan prasyarat tur. Audiens kedua: engineering manager dan rekan teknis yang ingin memeriksa ketepatan, sumber, serta keputusan engineering.

| Kedalaman | Yang terlihat | Kebutuhan |
|---|---|---|
| Ikuti ceritanya | Token, aliran, penjelasan singkat | Gambaran besar |
| Lihat angkanya | Shape, matriks, baris/kolom, operasi | Mekanisme konkret |
| Detail teknis | Bias, formula, pseudocode, provenance, sumber | Verifikasi dan eksplorasi |

Pengunjung dapat mengganti kedalaman tanpa mengulang tur. Bahasa utama Indonesia, istilah teknis disertakan dengan glossary singkat.

## 3. North star

> Setelah satu tur, pengunjung dapat menjelaskan bagaimana satu token keluaran dipilih dan menelusuri setidaknya satu angka dari input operasi sampai hasilnya.

**North-star metric:** jumlah sesi belajar berhasil per bulan. Sesi memenuhi syarat setelah menyelesaikan jalur input→next-token, membuka satu derivasi angka, dan menjawab benar minimal 2 dari 3 checkpoint. Ini indikasi pemahaman, bukan bukti menguasai seluruh LLM.

Metrik pendamping: mulai lab dari artikel, penyelesaian tur, penggunaan inspector, load failure, penggunaan 2D, dan klik menuju profil/source. Event cukup berisi ID eksperimen/stasiun serta hasil checkpoint, tanpa teks input. Analytics opsional; produk tetap berjalan tanpa tracking. Belum ada statistik nyata yang boleh dipresentasikan sebagai pencapaian.

Hipotesis: dalam 30 detik pengguna mengetahui input/output; dalam tur 8–12 menit mereka dapat membedakan Q/K/V dan menjelaskan autoregresi. Uji pada 5–8 orang IT/data dengan tugas dan penjelasan ulang. Target awal usability: sedikitnya 4 dari 5 peserta pertama menyelesaikan tur tanpa bantuan navigasi. Revisi berdasarkan pengamatan.

## 4. Arah visual: observatorium komputasi

Ruang terasa seperti laboratorium riset terbuka untuk pengunjung: keramik terang, rangka metal gelap, panel berkontras tinggi, cahaya cyan/amber terarah. Kejelasan operasi menjadi fokus; tidak ada kabut pekat atau teks kecil yang tenggelam dalam neon.

Delapan area dalam ruangan 36 × 24 meter membentuk jalur U. Tujuh area menyusun perjalanan inference; area kedelapan adalah annex analogi. Rak Transformer menjadi landmark tinggi. Rel cahaya memberi arah tanpa permainan mencari jalan.

```text
UTARA / dinding instrumen
┌──────────────────────────────────────────────────────────────┐
│ 01 Tokenizer → 02 Embedding → 03 QKV → 04 Attention            │
│                                               ↓              │
│             koridor / overview / kamera aman                  │
│                                               ↓              │
│ 08 Analogi     07 KV cache ← 06 Sampling ← 05 Transformer      │
└──────────────────── pintu masuk ──────────────────────────────┘
SELATAN
```

Jalur inference kembali dari sampling/cache menuju token baru. Annex analogi tidak wajib dilewati. Nomor, nama, siluet instrumen, tombol fokus, dan pertanyaan utama membedakan tiap stasiun. Q cyan, K violet, V amber, output hijau; warna selalu disertai label. Lebar beam attention menyatakan bobot, bukan jumlah paket jaringan. Angka berubah hanya saat langkah berubah.

## 5. Perjalanan kunjungan

### Sebelum masuk

Halaman blog menampilkan judul, overview lab, deskripsi, estimasi durasi, tombol **“Ikuti satu token”**, dan **“Baca tanpa 3D”**. Canvas berat baru dimuat sesudah masuk. Outline pelajaran tersedia selama loading.

Cakupan jelas: referensi GPT-2, angka demonstrasi, inference satu urutan. “Mengapa GPT-2?” menjelaskan keterlacakan implementasi, tanpa mengklaim semua LLM modern memakai detail yang sama.

### Tur pertama

Contoh cerita memakai prompt sederhana seperti `The cat sat on the`. Tokenisasi dan angka mengikuti profil fixture yang ditandai jelas. Satu token diberi outline putih dan ID tetap untuk dilacak ketika representasinya berubah.

Setiap stasiun mengikuti ritme **pertanyaan → kondisi awal → aksi → perubahan → penjelasan**. Pengunjung menekan “Lanjut”; tidak dipaksa menonton film panjang. Satu dot product dijelaskan penuh, operasi berulang dapat dipercepat. Setelah token dipilih, token baru masuk kembali ke urutan untuk menunjukkan loop generation.

### Setelah tur

Tiga checkpoint konsep memberikan penjelasan untuk jawaban salah dan tautan kembali ke langkah relevan. Pengunjung dapat mencoba eksperimen lain atau membaca catatan teknis pemilik portofolio: kode, keputusan desain, referensi, dan batas visualisasi. Profil/kontak tidak memotong pelajaran.

## 6. Fitur secara konkret

### Navigasi: guided, orbit, POV

Guided tour menjadi default dengan posisi kamera yang memudahkan membaca instrumen. Klik peta langsung memfokuskan stasiun. “Kembali ke tur” melanjutkan snapshot terakhir.

Orbit untuk rotate/zoom satu instrumen. POV melalui **“Jelajahi lab”**: WASD/arrow berjalan, mouse melihat, ESC keluar, Home ke posisi aman. Tidak perlu lompat atau mencari gerbang. Saat inspector/input fokus, kamera tidak bergerak karena mengetik.

Mobile memakai tap-to-focus, orbit terbatas, dan tombol next/previous. Reduced motion memakai perpindahan langsung. Semua tujuan belajar dapat dicapai tanpa kemampuan navigasi 3D.

### 01 — Tokenizer bench

Teks berada di conveyor. “Pisahkan token” mengubah kelompok karakter menjadi kapsul. Klik kapsul membuka teks, posisi string, ID beserta profil tokenizer, dan whitespace. Posisi urutan tidak disamakan dengan token ID.

Preset membandingkan kata umum/tidak umum, spasi awal, serta bahasa Indonesia. Pengunjung belajar bahwa satu token tidak selalu satu kata. Zoom BPE memperlihatkan merge menurut aturan yang sudah dipelajari. Jangan memotong kata menjadi bagian yang tampak masuk akal lalu menyebutnya tokenisasi GPT-2.

Vocabulary mini berlabel “tokenizer mainan”; ID/offset GPT-2 harus diverifikasi. V1 memakai preset, tanpa kotak input bebas yang seolah memahami apa pun.

### 02 — Embedding dan posisi

Kapsul masuk meja proyeksi. Lookup menyorot satu baris embedding; token ID tidak diperlakukan sebagai nilai semantik. Strip delapan sel memperlihatkan vektor demo. Strip posisi ditambahkan elemen demi elemen: `X = E[token] + P[position]`.

Pengunjung menukar posisi dua token: embedding token tetap, kontribusi posisi berubah. Profil GPT-2 memakai learned position lookup, bukan sinusoidal. Ruang 3D berlabel koordinat ilustratif/proyeksi, bukan tiga sumbu makna universal.

### 03 — Q/K/V

Satu representasi bercabang ke tiga papan. Tampilkan `U=LayerNorm(X)`, lalu `U Wq`, `U Wk`, `U Wv`. Memilih elemen hasil menyorot baris input, kolom weight, pasangan perkalian, dan penjumlahan. Shape tetap terlihat.

Analogi awal: Query adalah pola yang dicocokkan, Key pola yang ditawarkan tiap posisi, Value informasi yang dicampurkan. Detail menjelaskan ketiganya vektor proyeksi terlatih dari urutan yang sama, bukan pertanyaan/dokumen tersendiri.

Mengganti head 1/2 memperbarui matriks, beam, dan weighted sum bersama. Tidak ada klaim universal “head tata bahasa” atau “head fakta”.

### 04 — Attention theater

Token query berada di baris, key di kolom. Klik `(i,j)` membuka `q_i · k_j`, scaling, mask, dan bobot softmax. Step bergerak multiply → sum → scale → mask → normalize → weighted sum.

Segitiga masa depan ditutup abu berarsir dengan label “belum tersedia”. Sebelum softmax `−∞`, sesudahnya nol. Klik mask menjelaskan alasannya tanpa membuat beam menembusnya. Jumlah bobot satu baris ditampilkan sebagai satu.

Saat `A V`, beam menunjukkan kontribusi tiap value ke vektor output. Bobot dan kontribusi numerik ditampilkan terpisah. Dua heads kemudian digabung melalui concat dan proyeksi output.

### 05 — Transformer gallery

Rak 12 tingkat menggambarkan blok model referensi. Klik tingkat membuka pre-norm attention, residual add, pre-norm MLP, dan residual add lagi. Label: “12 blok referensi; 2 blok demonstrasi numerik”.

Jalur amber membawa residual. Pengunjung membandingkan `X`, hasil sublayer, dan jumlahnya pada dimensi tertentu. Normalization chamber menampilkan statistik satu token sepanjang feature dimension. MLP memperluas representasi, menerapkan GELU, lalu mengembalikannya ke lebar semula.

Aktivasi digambar berdasarkan tanda dan magnitude, bukan sakelar hidup/mati pada nol. Kurva GELU ada di inspector. Narasi tidak menunjuk satu neuron sebagai tempat satu fakta.

### 06 — Sampling amphitheater

Representasi posisi terakhir melewati final LayerNorm dan proyeksi vocabulary. Pilar menunjukkan probabilitas; tab lain menunjukkan logits. Lima kandidat terbesar dilengkapi massa “lainnya”.

Temperature mengubah bentuk distribusi. Greedy memilih argmax; sampling mempunyai seed dan tombol “Ambil satu sampel”. Seed berbeda dapat memberi pilihan berbeda dari distribusi sama. Top-k/top-p dibuka setelah softmax dasar, dengan visual penyaringan dan renormalisasi.

Distribusi lebih datar berarti pilihan lebih beragam, bukan otomatis lebih pintar. Probabilitas tinggi bukan jaminan fakta benar. Persentase harus berasal dari fixture/perhitungan, bukan angka dekoratif.

### 07 — Decode dan KV cache

Token terpilih masuk ke urutan. Tanpa cache, pekerjaan prefix digambarkan kembali. Dengan cache, laci K/V lama tetap terisi, token baru menambah satu baris per layer, query baru menghadap keys tersedia.

Bandingkan penghitung pekerjaan ilustratif, bukan latency model nyata. Edit prefix mereset cache. Pengunjung membedakan weights tetap, aktivasi per langkah, dan cache untuk urutan sama; cache bukan memori lintas pengguna.

### 08 — Annex analogi vektor

`king − man + woman ≈ queen` diperkenalkan sebagai contoh word embeddings statis yang populer, bukan mekanisme literal GPT menjawab. Panah ujung-ke-pangkal menunjukkan pengurangan/penjumlahan, tabel memperlihatkan komponen vektor mainan.

Hasil dibandingkan melalui ranking cosine pada vektor sumber. Tulisan: **“mendekati queen pada fixture ini”**; tidak menjanjikan identitas tepat atau berlaku untuk semua embeddings. Sumbu cukup dimensi 1/2/3 atau komponen proyeksi, bukan gender/royalty universal. Relasi contoh bukan definisi identitas manusia.

“Apa bedanya dengan GPT?” membawa pengguna ke representasi kontekstual yang berubah setelah blok menurut prefix. Latar konsep: [riset word representations](https://arxiv.org/abs/1301.3781). Fixture/proyeksi produk tetap ilustratif.

### Matrix inspector dan kontrol waktu

Panel kanan desktop memiliki tab Makna, Angka, Kode. Mobile memakai bottom sheet yang dapat menjadi tabel penuh. Inspector: nama tensor, shape, head/layer/token, sumber input, nilai presisi, formula. Canvas boleh membulatkan; perhitungan memakai presisi penuh.

Play/pause, previous/next operation, replay, dan kecepatan 0,25×–2× selalu tersedia. Scrubber kembali deterministik. Pergantian skenario menunjukkan reset yang jelas. “Salin tautan langkah ini” membagikan state teknis tanpa prompt privat.

Kode diberi label pseudocode atau implementasi referensi sesuai isinya. Baris aktif mengikuti operasi. Tidak ada tombol eksekusi PyTorch palsu.

## 7. Katalog eksperimen

| ID | Tindakan | Perubahan terlihat | Tujuan |
|---|---|---|---|
| A — One token journey | Ikuti prompt sampai token baru | Pipeline dan loop | Autoregresi |
| B — Subword microscope | Bandingkan kata/spasi/bahasa | Kapsul, offsets, posisi | Token ≠ kata |
| C — Trace attention | Pilih query/key/head, step | Dot product sampai AV | Q/K/V dan asal angka |
| D — Can `it` see the future? | Ganti suffix `tired/wide` | Baris `it` tetap; akhir bisa berubah | Causal attention |
| E — Vector arithmetic | Jalankan king−man+woman | Panah dan cosine ranking | Relasi geometris |
| F — Same logits, different choice | Temperature/mode/seed | Distribusi dan pilihan | Ranking vs probability vs sample |
| G — Reuse the past | Tambah token, cache on/off | K/V lama dan baris baru | Prefill/decode/cache |

### Detail eksperimen D: konteks tanpa melanggar kausalitas

Bandingkan `The animal did not cross the street because it was too tired` dengan versi berakhir `wide`. Tugas pertama: “Pilih it. Bolehkah perubahan kata sesudahnya mengubah attention di posisi ini?” Tidak: prefix sampai `it` identik.

Tugas kedua memilih query pada kata akhir, ketika informasi konteks sudah tersedia. Vignette boleh memperlihatkan bobot berbeda ke `animal/street`, dengan label ilustrasi, bukan pengukuran GPT-2. Jika preset melewati batas 12 token demo, gunakan contoh lebih pendek atau overview word-level berlabel; jangan diam-diam menyebut setiap kata satu token BPE.

## 8. Storyboard attention, sekitar 90 detik

1. **0–10 detik:** fokus QKV; pilih query. Satu representasi menjadi tiga proyeksi.
2. **10–30:** empat pasangan angka dari dot product masuk subtotal; dapat dipause.
3. **30–45:** scaling dan causal mask; masa depan tidak tersedia.
4. **45–60:** softmax membentuk distribusi baris; bandingkan skor dan bobot.
5. **60–80:** `A V` mengumpulkan kontribusi; telusuri satu koordinat output.
6. **80–90:** checkpoint “Apakah K dijumlahkan menjadi output?” Value vectors yang dijumlahkan dengan bobot; keys menentukan kecocokan.

Durasi hanya panduan konten, bukan batas waktu pengguna.

## 9. Interface dan microcopy

Canvas sekitar dua pertiga lebar desktop, inspector kanan, breadcrumb atas, timeline bawah. Daftar eksperimen dapat ditutup. Fullscreen opsional. Matriks punya tombol “Buka tabel” agar pengguna tidak perlu mendekatkan kamera hanya untuk membaca angka.

Contoh teks:

- “Q · Head 1 · Blok demo 1 · Token 4.”
- “Angka simulasi. Dimensi 8 mempermudah pelacakan.”
- “Masa depan belum tersedia pada posisi ini.”
- “Kandidat lainnya menyimpan sisa probabilitas.”
- “3D tidak tersedia. Pelajaran tetap dapat dilanjutkan.”
- “Kembali ke tur” / “Lihat operasi angka” / “Ulangi langkah”.

Hindari “AI sedang berpikir” sebagai fakta, progress inference palsu, dan permintaan prompt privat. Vignette lokal dilabeli sebelum disambungkan secara naratif ke tahap lain.

## 10. Scope

**V1 lengkap:** delapan area, tujuh eksperimen, tur token, tiga kedalaman, guided/orbit/POV desktop, mobile tap-to-focus, inspector, timeline, provenance, HTML fallback, deep link, sumber teori. Indonesia terlebih dahulu; audio opsional.

**Slice pertama:** satu perjalanan token dan attention vignette yang dapat ditelusuri sampai `A V`. Pastikan kualitas penjelasan sebelum animasi seluruh ruangan.

**Sesudah v1:** input tokenizer bebas yang benar, profil GPT-2 vs arsitektur modern secara terpisah, bahasa Inggris, audio, training/gradient, atau inference kecil asli dengan penanda berbeda.

**Di luar scope:** chatbot layanan, backend inference, training model, multiuser, VR wajib, gameplay, akun, leaderboard, visualisasi semua neuron model 175B, atau reproduksi chain-of-thought model nyata.

## 11. Acceptance criteria

| Area | Syarat selesai |
|---|---|
| Entry | Pilihan tur, eksplorasi, baca 2D tersedia |
| Alur | Input sampai token baru dan decode dapat diikuti tanpa dead end |
| Attention | Satu sel ditelusuri sampai AV, mask dan row sum benar |
| Profil | Formula GPT-2 konsisten; arsitektur lain terpisah |
| Provenance | Tidak ada ID/persentase/hasil dummy dipresentasikan sebagai pengukuran asli |
| Kontrol | Pause, back, replay, Home, ESC, pergantian skenario tidak mencampur state |
| Akses | Tujuan belajar tersedia melalui HTML/keyboard; mobile tanpa WASD |
| Performa | Budget system.md diuji pada perangkat nyata |
| Portofolio | Keputusan teknis, sumber, dan batasan dapat diperiksa |
| Aset | Tiap instrumen dapat ditinjau; source generator/manifest/lisensi tersedia |

## 12. Deliverable tahap ini

`system.md` dan `product.md` menjadi spesifikasi utama. Kit GLB, generator, manifest, layout, serta katalog inspeksi disediakan. Kit mencakup geometri statis v1; angka/efek dinamis dijelaskan melalui kontrak implementasi.

Jalankan `npm run assets:preview` untuk melihat ruangan dan mengorbit setiap modul. Katalog adalah alat review aset, bukan tur pembelajaran yang telah selesai. Implementasi runtime produk mengikuti tahapan pada system.md.
