# Asset validation

Validated 26 GLB files using Khronos glTF Validator 2.0.0-dev.3.10 and Three.js GLTFLoader.

Errors: **0**. Warnings: **0**. GLB total: **1.23 MiB**.

Every asset passes byte-size and SHA-256 checks, import round-trip, mesh/triangle/socket counts, finite positions/normals, and bounding-box comparison.

| Asset | Triangles | Mesh nodes | Errors | Warnings |
|---|---:|---:|---:|---:|
| floor-tile | 36 | 3 | 0 | 0 |
| wall-panel | 156 | 5 | 0 | 0 |
| structural-arch | 348 | 5 | 0 | 0 |
| station-plinth | 228 | 3 | 0 | 0 |
| operator-console | 576 | 8 | 0 | 0 |
| wayfinding-pylon | 240 | 4 | 0 | 0 |
| data-rail | 120 | 2 | 0 | 0 |
| token-capsule | 132 | 3 | 0 | 0 |
| vector-arrow | 72 | 2 | 0 | 0 |
| neuron-bead | 80 | 1 | 0 | 0 |
| signal-packet | 8 | 1 | 0 | 0 |
| matrix-cell | 108 | 1 | 0 | 0 |
| tokenizer-bench | 1464 | 34 | 0 | 0 |
| embedding-projector | 3460 | 22 | 0 | 0 |
| matrix-board | 564 | 23 | 0 | 0 |
| qkv-projector | 1104 | 52 | 0 | 0 |
| attention-workbench | 1380 | 49 | 0 | 0 |
| causal-mask | 180 | 15 | 0 | 0 |
| head-combiner | 1264 | 8 | 0 | 0 |
| transformer-stack | 2220 | 42 | 0 | 0 |
| normalization-chamber | 1680 | 7 | 0 | 0 |
| mlp-lattice | 3364 | 27 | 0 | 0 |
| residual-conduit | 464 | 2 | 0 | 0 |
| logits-amphitheater | 1168 | 13 | 0 | 0 |
| kv-cache-rack | 2328 | 66 | 0 | 0 |
| lab-assembled | 25260 | 624 | 0 | 0 |

This report checks asset integrity. It does not establish production FPS, accessibility compliance, or completion of the learning simulator. Visual review is recorded separately in visual-review.md.
