# Visual review — 14 Oktober 2026

Katalog dimuat melalui HTTP lokal dan diperiksa di browser desktop. Scene lab,
tokenizer, embedding projector, QKV, attention workbench, Transformer stack,
MLP lattice, sampling, dan KV cache berhasil dirender. Screenshot tersimpan
di `previews/`.

Yang diperiksa:

- Kesesuaian siluet instrumen, palet Q/K/V, orientasi, dan susunan delapan area.
- Attention menampilkan bagian segitiga masa depan berbeda dari sel aktif.
- Model berdiri pada alas dan tidak menunjukkan geometri hilang pada sudut inspeksi.
- Pemilihan model mengganti judul, catatan, jumlah triangles, ukuran file, dan URL unduhan.
- Pencarian `cache` menyaring daftar ke KV Cache Rack.
- Tombol Demo geometry menyembunyikan sel/contoh statis; instrumen tetap terlihat.
- Wireframe mengubah rendering menjadi topology lines; dapat dikembalikan.
- Browser tidak mencatat console error/warning pada rangkaian pemeriksaan terakhir.
- Tata letak desktop diperbaiki agar panel detail dan kontrol tidak terdorong keluar viewport.

Regenerasi kedua menghasilkan manifest dan SHA-256 seluruh GLB yang identik.
Validator resmi dan import round-trip dilaporkan pada [asset-validation.md](asset-validation.md).

## Screenshot

![Overview](previews/lab-overview.jpg)
![Tokenizer](previews/tokenizer.jpg)
![Embedding](previews/embedding.jpg)
![QKV](previews/qkv-projector.jpg)
![Attention](previews/attention.jpg)
![Transformer](previews/transformer.jpg)
![MLP](previews/mlp.jpg)
![Sampling](previews/sampling.jpg)
![KV cache](previews/kv-cache.jpg)

## Batas verifikasi

Review ini bukan benchmark GPU/mobile, audit aksesibilitas produk, atau uji
simulator pembelajaran. Aset tidak berisi angka dinamis, inference, animation
clips, atau implementasi POV. Semua 26 GLB divalidasi dan diimpor ulang secara
programatik; review visual manual berfokus pada scene dan instrumen utama.

Scene referensi menggunakan atap terbuka dan dinding parsial untuk memudahkan
inspeksi. Tampilan reverse dari instrumen baris selatan pada overview memang
sesuai orientasi mereka ke koridor tengah; gunakan model individual untuk
melihat muka tiap instrumen.
