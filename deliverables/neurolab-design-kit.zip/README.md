# NeuroLab — rancangan dan aset 3D

Laboratorium visual untuk mempelajari aliran decoder-only Transformer dengan GPT-2 sebagai referensi arsitektur. Angka pembelajaran dirancang sebagai simulasi terkurasi, bukan inference model asli.

- [system.md](system.md): stack, alasan pemilihan, pipeline tensor, fixture, rendering, kamera, integrasi blog, performa, dan QA.
- [product.md](product.md): north star, perjalanan pengguna, delapan stasiun, tujuh eksperimen, perilaku fitur, dan batas scope.
- [Kit aset](public/assets/lab-v1/README.md): 25 modul GLB + satu susunan lab, manifest, layout, dan lisensi.
- [Validasi aset](docs/asset-validation.md): laporan validator dan impor ulang.
- [Catatan visual](docs/visual-review.md): review pratinjau.

## Tinjau aset

```sh
npm ci
npm run assets:preview
```

Buka [katalog lokal](http://127.0.0.1:4173/preview/) saat server berjalan. Pilih model, orbit, zoom, wireframe, sembunyikan demo geometry, atau unduh GLB. Katalog memakai dependency lokal; tidak memerlukan CDN atau kunci API.

## Regenerasi

```sh
npm run assets:generate
npm run assets:validate
```

Source parametrik tersedia di `scripts/generate-lab-assets.mjs`. Menjalankan ulang menimpa keluaran kit di `public/assets/lab-v1`; ubah generator untuk menyimpan perubahan desain. Dependency terkunci di package-lock.json.

**Status:** spesifikasi dan kit aset tersedia. Katalog hanya alat inspeksi; tur, perhitungan fixture, POV, dan inspector pembelajaran pada product.md adalah pekerjaan implementasi berikutnya. Tidak ada deployment atau layanan inference pada paket ini.
