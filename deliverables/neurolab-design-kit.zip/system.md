# NeuroLab — System Design

Status: rancangan implementasi v1, 14 Oktober 2026. Pasangan dokumen: [product.md](product.md).

Paket tahap ini berisi spesifikasi, aset 3D, generator, dan katalog inspeksi. Simulator pembelajaran lengkap belum diimplementasikan. Target performa di bawah adalah acceptance budget, bukan hasil benchmark.

## 1. Keputusan inti

Bangun simulator edukasi client-side berbasis **React + TypeScript + Three.js + React Three Fiber (R3F)**. Render 3D melalui WebGL2; penjelasan dan angka detail melalui HTML. Guided tour menjadi default, dengan POV dan orbit sebagai pilihan. Konten tetap dapat dibaca sebagai artikel tanpa menyalakan 3D.

Referensi utama adalah **GPT-2 small**, karena implementasi publiknya dapat ditelusuri dan arsitekturnya cukup representatif untuk mempelajari decoder-only autoregressive Transformer. Profil referensi: 12 blok, 12 attention heads, hidden width 768, context 1.024, vocabulary 50.257. Ini metadata referensi; browser tidak memuat bobotnya. [Konfigurasi GPT-2](https://huggingface.co/openai-community/gpt2/blob/main/config.json).

Profil demonstrasi memakai `d_model=8`, `heads=2`, `d_head=4`, `d_ff=32`, dua blok numerik, vocabulary mainan 16 kandidat, panjang urutan maksimal 12 token. Selalu tampilkan label **“angka simulasi · dimensi diperkecil”**. Rak 12 lapis menjelaskan skala model referensi; dua blok fixture bukan hasil pemotongan bobot GPT-2.

Nilai pembelajaran berasal dari fixture terkurasi yang dapat direproduksi. Tidak ada inference model asli, API LLM, training, GPU compute, database, atau akun pengguna. Perhitungan kecil saat pembuatan fixture dan untuk slider probabilitas diperbolehkan agar matematika konsisten; tidak perlu melatih model agar menghasilkan kalimat.

## 2. Analisis stack

| Pilihan | Kesesuaian | Keputusan |
|---|---|---|
| React + R3F + Three.js | Scene interaktif dan inspector HTML berbagi state; cocok untuk integrasi komponen blog | Dipilih untuk produk |
| Vanilla Three.js | Baik untuk renderer kecil; banyak panel dan route memerlukan sinkronisasi manual | Dipakai untuk generator/katalog aset |
| Babylon.js | Engine lengkap, berguna jika berkembang ke gameplay/editor/physics | Layak, tetapi cakupannya melebihi kebutuhan v1 |
| Unity/Godot web export | Cocok untuk pipeline game; integrasi artikel HTML perlu lapisan tambahan | Tidak dipilih untuk blog ini |
| WebGPU renderer | Menarik untuk eksperimen; compute tidak diperlukan oleh fixture | Evaluasi setelah v1 |

WebGL2 dipilih untuk kompatibilitas pengalaman dan ekosistem yang telah matang. WebGPURenderer punya fallback WebGL2, tetapi custom ShaderMaterial dan pipeline postprocessing WebGL tidak otomatis kompatibel. Hindari migrasi renderer bersamaan dengan pengembangan konten. [Dokumentasi renderer](https://threejs.org/manual/pages/webgpurenderer), [WebGLRenderer](https://threejs.org/docs/pages/WebGLRenderer.html).

### Library per tanggung jawab

| Area | Library / mekanisme | Penggunaan konkret |
|---|---|---|
| UI/build | React, TypeScript, Vite | Shell, inspector, artikel, type checking |
| Scene | `three`, `@react-three/fiber` | Mesh, kamera, raycast, lifecycle, render loop |
| Helper | `@react-three/drei` | `useGLTF`, `OrbitControls`, `PointerLockControls`, `Text`, `Html`, `PerformanceMonitor` |
| State | `zustand` | Skenario, frame, token, head, layer, kamera, preferensi |
| Timeline | Fungsi murni + `useFrame` | Pose menurut waktu absolut, seek/replay deterministik |
| Kamera | Interpolasi Three.js | Satu pemilik pose; tidak perlu GSAP untuk v1 |
| Rumus | `katex` | Formula HTML dan teks alternatif; CSS lokal |
| Grafik 2D | SVG + CSS | Probability bars, GELU, heatmap kecil; tanpa chart library |
| Validasi data | `zod` | Validasi fixture dan manifest sebelum dipakai |
| Kode | Shiki saat build | Highlight cuplikan pseudocode/PyTorch; tidak mengeksekusinya |
| Styling | CSS variables + CSS | Layout responsif, tema, focus ring, reduced motion |
| Postprocessing | Opsional `@react-three/postprocessing` + `postprocessing` | Bloom ringan di high; mati di low |
| Tes | Vitest, Playwright, axe-core | Invarian, interaksi, keyboard, fallback |
| Generator aset | Node.js + Three.js `GLTFExporter` | Geometri parametrik dan ekspor GLB |
| QA aset | Khronos glTF Validator + `GLTFLoader` | Format, buffer, normals, hierarchy, impor |

Jangan memakai `Html` untuk setiap sel. Jarak jauh: warna/tinggi instanced mesh; angka detail hanya pada matriks aktif. Maksimal 64 label angka 3D desktop dan 16 mobile; tabel lengkap berada di HTML. Instancing mengurangi draw calls pada geometri/material yang sama, bukan otomatis membuat semua objek menjadi satu draw call. Perubahan per frame memakai refs, tanpa React setState 60 kali per detik. [Performa R3F](https://r3f.docs.pmnd.rs/advanced/scaling-performance), [performance pitfalls](https://r3f.docs.pmnd.rs/advanced/pitfalls).

### Versi dan instalasi

Paket aset pada tahap ini hanya memasang Three.js 0.169.0 dan glTF Validator, terkunci dalam lockfile. Versi ini dipakai untuk generator/katalog yang dapat direproduksi, bukan rekomendasi bahwa itu versi terbaru.

Target implementasi produk: React 19 + R3F 9, dengan Drei/Three yang peer dependencies-nya cocok dan versi stabil Vite/TypeScript saat implementasi dimulai. Audit dependency lalu commit lockfile sebelum rilis. React 18 + R3F 8 tetap pasangan valid untuk host lama; jangan mencampur React 19 dengan R3F 8. Library produk pada tabel adalah rencana, belum semuanya terpasang. [Kompatibilitas resmi R3F](https://r3f.docs.pmnd.rs/getting-started/introduction).

## 3. Arsitektur aplikasi

```mermaid
flowchart TD
  A[Blog article / transcript] --> B[Launch lab]
  B --> C[Capability check + lazy assets]
  C --> D[Experience store]
  E[Versioned scenario fixtures] --> F[Schema validation]
  F --> G[Deterministic timeline evaluator]
  D --> G
  G --> H[Frame snapshot]
  H --> I[Three.js scene + camera]
  H --> J[HTML matrix inspector + formulas]
  H --> K[Accessible linear lesson]
  L[GLB manifest + layout] --> I
```

Empat lapisan dipisahkan:

1. **Content:** narasi, glossary, pertanyaan, sitasi, pseudocode. Bahasa Indonesia default dengan istilah teknis tetap disertakan.
2. **Scenario engine:** fixture dan snapshot; tidak mengetahui Three.js atau DOM.
3. **Presentation:** snapshot menjadi angka, highlight, partikel, opacity, dan penjelasan. Semua panel memakai snapshot sama.
4. **Navigation:** kamera dan fokus. Mengunjungi stasiun tidak otomatis mengubah input eksperimen.

Struktur target aplikasi:

```text
src/
  app/              # shell, route, error boundary, capability gate
  content/id/       # lessons, glossary, checkpoints, references
  simulation/       # schema, fixture loader, timeline evaluator
  scenarios/        # JSON; tensor lineage + variants
  scene/            # renderer, quality, lighting, camera, picking
  stations/         # tokenizer, embedding, qkv, attention, block, sampler, cache, analogy
  inspector/        # matrix, scalar derivation, shape, formula, code
  navigation/       # station map, tour, input ownership, deep links
  store/            # serializable state; tidak menyimpan scene objects
public/assets/lab-v1/ # GLB, manifest, layout, licensing
scripts/             # fixture builder, asset generator, validator
```

Jangan mengasumsikan stack portofolio memakai Next.js. Lab menerima `assetBaseUrl`, locale, dan exit link. Pada Next.js, canvas client-only/dynamic import; artikel tetap server-rendered. Pada Astro, hidrasi lab sesudah tombol masuk. Pada Vite, prerender artikel saat integrasi SEO. Gunakan base URL agar subpath blog bekerja. Iframe menjadi opsi isolasi jika stack host tidak kompatibel, dengan title dan ukuran responsif.

## 4. Kontrak ilmiah

### Pipeline GPT-2 yang konsisten

```text
text → byte-level BPE → token IDs
X0 = token_embedding[ids] + learned_position_embedding[positions]

untuk setiap blok:
  U = LayerNorm_1(X)
  Q = U Wq + bq; K = U Wk + bk; V = U Wv + bv
  split heads
  scores = Q Kᵀ / sqrt(d_head)
  scores[i,j] = -∞ ketika j > i
  A = softmax(scores, axis=key)
  Z = A V
  attention_out = concat(Z_heads) Wo + bo
  R = X + attention_out
  N = LayerNorm_2(R)
  M = GELU(N W1 + b1) W2 + b2
  X = R + M

H = LayerNorm_final(X)
logits = H[last_position] Eᵀ
probabilities = softmax(logits / temperature)
next_token = sample(probabilities) atau argmax(logits)
append token → ulangi decode
```

Pre-norm, learned position, GELU, dua residual add, final LayerNorm, serta tied output embedding mengikuti GPT-2. Diagram utama tidak mencampurkan sinusoidal position, RoPE, RMSNorm, atau SwiGLU. Implementasi referensi memakai proyeksi gabungan QKV; tiga panel adalah pemecahan pedagogisnya. [Kode GPT-2](https://github.com/openai/gpt-2/blob/master/src/model.py).

Bias boleh disembunyikan pada tampilan ringkas, tetapi tersedia di inspector. Jika bias fixture nol, labelkan nilainya. GELU bukan sakelar positif/negatif; MLP bukan satu neuron untuk satu fakta. Attention matrix bukan bukti lengkap penyebab keputusan model. Narasi mengajarkan operasi, tanpa mengklaim membaca pikiran model.

### Bentuk tensor demonstrasi

Batch tunggal tidak ditampilkan dalam UI; bentuk lengkap menyertakan `B=1`.

| Tensor | Bentuk UI, panjang N | Contoh N=6 |
|---|---|---|
| X / U / R / H | N × 8 | 6 × 8 |
| Wq / Wk / Wv | 8 × 8 | 8 × 8 |
| Q/K/V sebelum split | N × 8 | 6 × 8 |
| Q/K/V per head | N × 4 | 6 × 4 |
| Scores / mask / A per head | N × N | 6 × 6 |
| Z per head | N × 4 | 6 × 4 |
| Concat / attention output | N × 8 | 6 × 8 |
| W1 / aktivasi / W2 | 8 × 32 / N × 32 / 32 × 8 | 6 × 32 untuk aktivasi |
| E / logits terakhir | 16 × 8 / 16 | vocabulary demonstrasi |

Invarian: `d_model = heads * d_head`. Setiap blok numerik terdiri dari attention **dan** MLP; bukan blok ganjil attention dan blok genap MLP. Rak 12 blok boleh disorot, tetapi mode angka hanya menawarkan dua blok fixture.

### Dua jenis fixture dengan label berbeda

**Pipeline fixture:** bobot mainan deterministik menghasilkan tensor lengkap dua blok secara matematis konsisten. Tensor disimpan offline sebagai JSON. Keluaran boleh tidak bermakna; jangan mengubahnya menjadi klaim kemampuan bahasa GPT-2.

**Concept vignette:** contoh lokal terkurasi untuk satu operasi, misalnya skor `[2,1,0]`, pola konteks sederhana, atau logits dengan kandidat kata yang masuk akal. Badge menyebut “contoh lokal” dan batas vignette eksplisit. Jangan mengaku logits vignette berasal dari tensor pipeline sebelumnya.

Setiap fixture menyimpan `kind`, `provenance`, `modelProfile`, `tokenizerProfile`, `seed`, `schemaVersion`, `contentVersion`, `inputs`, `tensors`, dan `steps`. Tidak ada angka random setiap render. Token BPE asli hanya boleh memakai ID dan offsets yang diverifikasi; vocabulary mainan memakai `toy:17`, bukan ID rekaan berlabel GPT-2. V1 menggunakan preset offline; input bebas baru dibuka setelah tokenizer dan limit divalidasi. [Encoder GPT-2](https://raw.githubusercontent.com/openai/gpt-2/master/src/encoder.py).

```ts
type Tensor = {
  id: string;
  shape: number[];
  values: number[];            // row-major, presisi penuh
  maskedIndices?: number[];   // JSON tidak menyimpan Infinity/NaN
  sourceTensorIds: string[];
  operation: string;
};
type Step = {
  id: string; station: string; durationMs: number;
  fromTensorIds: string[]; toTensorIds: string[];
  focus?: { row: number; column: number; head: number; layer: number };
  narrationKey: string;
};
```

Snapshot memuat nilai sebelum/sesudah, scalar derivation, token/head/layer, mask, dan operasi. Mask JSON terpisah ditampilkan sebagai `−∞`, kemudian nol setelah softmax. Angka interpolasi diberi status transisi; hanya endpoint dipresentasikan sebagai hasil matematika. Skip/pause/seek harus mengambil state dari evaluator, bukan menebak progres tween sebelumnya.

### Contoh lokal yang dapat diaudit

Pilih `q=[2,0,0,0]` dan keys `[2,0,0,0]`, `[1,0,0,0]`, `[0,0,0,0]`. Dot products `[4,2,0]`, dibagi `sqrt(4)=2` menghasilkan `[2,1,0]`. Jika semua keys boleh dilihat, softmax ≈ `[0.665241,0.244728,0.090031]`.

Dengan `V=[[1,0,0,0],[0,2,0,0],[0,0,3,0]]`, weighted sum ≈ `[0.665241,0.489457,0.270092,0]`. Jika key ketiga berada di masa depan, skor terakhir `−∞`, bobot `[0.731059,0.268941,0]`, hasil `[0.731059,0.537883,0,0]`. Kedua contoh memakai posisi query yang sesuai; tombol eksperimen tidak mengubah aturan decoder diam-diam.

Softmax stabil: `exp(z_i-max(z)) / sum(exp(z_j-max(z)))`. Terapkan temperature pada logits terlebih dahulu. `T=0` adalah mode greedy melalui argmax, tanpa pembagian nol. Pada T positif peringkat logits tetap; probabilitas berubah. Top-k/top-p menyaring lalu renormalisasi. Jika hanya lima dari 16 kandidat ditampilkan, sertakan massa “lainnya”, bukan menormalisasi ulang kelimanya diam-diam.

### Causal consistency dan KV cache

Mengubah suffix sesudah posisi i tidak mengubah hidden state/attention row posisi i untuk prefix yang sama. Eksperimen `it ... tired/wide` wajib mempertahankan baris `it`. Perbandingan pola konteks dapat menggunakan query di posisi kata akhir; bobot vignette tetap ilustratif.

Prefill memproses prompt paralel dengan causal mask. Decode berikutnya menghasilkan query dan K/V untuk token baru pada setiap layer; K/V lama dipakai ulang. Cache bukan weights dan bukan memori lintas percakapan. Edit prefix membatalkan cache yang bergantung padanya; v1 dapat mereset seluruh cache. Ukuran per layer: `2 × N × heads × d_head × bytesPerElement`, dengan label estimasi, bukan benchmark model nyata. [Penjelasan cache Hugging Face](https://huggingface.co/docs/transformers/main/cache_explanation).

## 5. State, timeline, kamera

```ts
type ExperienceState = {
  scenarioId: string; fixtureVersion: string;
  stationId: string; stepId: string; progress: number;
  playing: boolean; speed: 0.25 | 0.5 | 1 | 2;
  selectedToken: number; selectedHead: number; selectedLayer: number;
  cameraMode: 'guided' | 'orbit' | 'walk';
  temperature: number; samplingMode: 'greedy' | 'sample'; sampleSeed: number;
  quality: 'low' | 'medium' | 'high'; reducedMotion: boolean;
};
```

`evaluate(scenario,stepId,progress)` murni dan dapat di-replay. Partikel memakai waktu yang sama. Berpindah skenario membatalkan transisi lama, memvalidasi indeks, dan memuat initial snapshot. Mengganti head/layer mempertahankan token terpilih; temperature hanya mengubah sampler. Tab tersembunyi mem-pause clock.

Hanya satu controller menulis pose kamera. Guided → transitioning → orbit/walk; input manual membatalkan transisi. Pointer lock hanya melalui klik eksplisit; ESC mengembalikan kursor. Ketika inspector/input fokus, WASD berhenti menggerakkan kamera. Walk: mata 1,65 m, kecepatan 2,5 m/s, collision AABB props dan batas koridor; tidak perlu physics engine. Home kembali ke posisi aman. Mobile: tap-to-focus/orbit, tanpa pointer lock.

Deep link menyimpan ID skenario/stasiun/step/head/layer/seed yang divalidasi, tanpa prompt sensitif. localStorage opsional untuk bahasa, kualitas, progres; kegagalan storage tidak menghambat pelajaran.

## 6. Dunia dan kontrak aset

**NeuroLab Observatory:** ruang 36 × 24 m, slate, keramik terang, layar gelap, pencahayaan netral. Jalur U menghubungkan tujuh stasiun dan satu annex analogi. Q cyan, K violet, V amber, aktivasi hijau, mask abu berarsir. Label/bentuk selalu mendampingi warna.

Kit asli di `public/assets/lab-v1/`:

| Kelompok | GLB |
|---|---|
| Arsitektur | `floor-tile`, `wall-panel`, `structural-arch`, `station-plinth`, `operator-console`, `wayfinding-pylon`, `data-rail` |
| Primitif | `token-capsule`, `vector-arrow`, `neuron-bead`, `signal-packet`, `matrix-cell` |
| Instrumen | `tokenizer-bench`, `embedding-projector`, `matrix-board`, `qkv-projector`, `attention-workbench`, `causal-mask`, `head-combiner`, `transformer-stack`, `normalization-chamber`, `mlp-lattice`, `residual-conduit`, `logits-amphitheater`, `kv-cache-rack` |
| Susunan | `lab-assembled.glb` |

Total: **25 modul + 1 scene gabungan**. `manifest.json` menyimpan ukuran, triangles, bounds, material, sockets, SHA-256; `layout.json` menyimpan stasiun dan kamera. `npm run assets:generate` meregenerasi kit. GLB menyatukan buffer/geometri/material tanpa file texture eksternal. [GLTFExporter](https://threejs.org/docs/pages/GLTFExporter.html).

Konvensi: meter, Y-up, +Z depan, origin lantai di tengah instrumen. Primitive vektor berorigin pangkal dan mengarah +Y. Node `socket_*` menjadi anchor label/data. Cari socket pada subtree instrumen karena nama lokal dapat berulang. Node `demo_*` adalah data visual statis pratinjau: sembunyikan sebelum memasang renderer dinamis. MLP 4→12→4 titik hanya menunjukkan bentuk expansion, bukan ukuran tensor 8→32→8.

Angka, teks, formula, beam, partikel, heatmap, dan pertumbuhan bar dibuat saat runtime. Tidak perlu GLB per angka. Aset tanpa skeleton/baked animation; animasi dikendalikan lewat nama node/material, sockets, dan timeline. Clone material jika satu instance perlu warna unik.

Scene gabungan adalah referensi layout, bukan build produksi yang sudah dioptimasi. Jangan memuatnya sekaligus dengan modul duplikat. Produksi merakit modul dari layout, batch mesh statis per material, instance tiles/cells, dan lazy-load detail stasiun. LOD v1 melalui culling, jumlah instance/label, kualitas bayangan; GLB decimated belum disediakan. Detail geometri arsitektur tidak boleh mengorbankan keterbacaan matriks.

Alternatif yang diperiksa: [Kenney Space Station Kit](https://kenney.nl/assets/space-station-kit), CC0. Tidak dimasukkan karena kit custom memberi bahasa visual dan socket yang seragam. Tidak ada kebutuhan texture/HDRI eksternal untuk v1. Model pihak ketiga di masa depan wajib dicatat URL asset spesifik, pembuat, lisensi, dan tanggal unduh; lisensi marketplace tidak mewakili seluruh isinya.

## 7. Performa, aksesibilitas, kegagalan

| Budget v1 | Target saat implementasi |
|---|---|
| Desktop 1080p integrated GPU | 50–60 FPS; p95 frame ≤25 ms |
| Mobile menengah, low | ≥30 FPS; DPR 1–1,25 |
| Initial article | Tidak memuat Three.js sebelum masuk |
| Initial lab transfer terkompresi | ≤3 MB: kode, shell, stasiun pertama |
| Full aset on demand | ≤10 MB; ukur setiap build |
| Geometry visible | ≤150k triangles desktop; ≤60k mobile |
| Draw calls | ≤180 desktop; ≤80 mobile |
| Respons step | Status UI berubah dalam 100 ms pada perangkat uji |

DPR desktop maksimal 1,5; satu shadow light pada high, fake/contact shadow pada low. Tanpa motion blur, chromatic aberration, depth of field, atau kabut yang mengganggu teks. Render idle berhenti ketika tidak ada animasi. Adaptive quality memakai hysteresis. Ukur di perangkat nyata sebelum mengklaim 60 FPS.

HTML menyediakan urutan pelajaran, rumus, tabel, dan kontrol yang sama. Semua hotspot memiliki pasangan tombol DOM. Reduced motion menonaktifkan camera flight, partikel, dan odometer; nilai akhir muncul langsung. Focus ring jelas, kontras teks minimal 4,5:1, mask tidak bergantung pada warna, tanpa audio autoplay.

WebGL2 gagal: mode artikel/diagram 2D. Asset gagal: lesson tetap tersedia, retry dan placeholder instrumen. GPU context lost: pause, simpan step, resume setelah restore atau pindah 2D. Fixture tidak valid: jangan tampilkan angka parsial; tawarkan preset valid. Pointer lock ditolak: orbit tetap berjalan.

## 8. Quality gates

- Shape dan jumlah elemen cocok; nilai finite; setiap operasi punya sumber.
- Probabilitas non-negatif, jumlah satu dengan toleransi 1e-6 sebelum pembulatan, mask nol tepat.
- Prefix invariance: edit suffix tidak mengubah snapshot prefix kausal.
- `A @ V`, concat, proyeksi, dua residual, dan LayerNorm cocok dengan operasi independen atas input fixture.
- Lima kandidat + massa lainnya berjumlah satu; greedy dan seed bekerja konsisten.
- Seek/replay/deep link memulihkan frame yang sama.
- Cache on/off memberi hasil toy pipeline sama; edit prefix menginvalidasi cache.
- Tokenizer preset dapat direkonstruksi menjadi teks input, termasuk whitespace/offsets.
- Cosine analogi dihitung pada vektor sumber, bukan pada proyeksi 3D.

QA interaksi: pergantian skenario saat animasi, ESC/Home, input ownership, keyboard-only, mobile, reduced motion, asset failure, WebGL failure. QA visual mencakup overview dan setiap stasiun. Asset QA: validator resmi dan round-trip `GLTFLoader`; status aktual dicatat pada `docs/asset-validation.md`.

## 9. Tahap implementasi

1. **Foundation:** schema, vignette attention benar, HTML inspector, deep link. Invarian lulus sebelum polish.
2. **Vertical slice:** tokenizer sampai satu token baru; step-back dan replay bekerja.
3. **Spatial experience:** scene modular, navigasi, token trail, angka dinamis, quality tiers.
4. **Eksperimen:** analogi, konteks kausal, temperature/top-p, KV cache, checkpoints.
5. **Portfolio readiness:** artikel SEO, referensi, accessibility, device QA, integrasi route.

Setiap tahap selesai berdasarkan perilaku yang diuji. Jangan mencampurkan sinusoidal/GPT-2, SwiGLU/GELU, atau post-norm/pre-norm untuk mempersingkat implementasi.

Referensi teori tambahan: [Attention Is All You Need](https://arxiv.org/abs/1706.03762) dan [Efficient Estimation of Word Representations](https://arxiv.org/abs/1301.3781). Desain ini merupakan sintesis edukasi, bukan reproduksi penuh paper pertama atau klaim interpretabilitas model produksi.
